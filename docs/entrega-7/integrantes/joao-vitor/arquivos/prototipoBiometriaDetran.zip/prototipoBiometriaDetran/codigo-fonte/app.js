'use strict';
(() => {
  const config = window.PROTOTYPE_CONFIG;
  const $ = id => document.getElementById(id);
  const state = { category: '', unit: '', date: '', time: '', phone: '', protocol: '', step: 0 };
  let appointment = null, waStarted = false, waMode = 'menu', messageCounter = 0;
  const today = new Date(new Date().toLocaleDateString('sv-SE',{timeZone:'America/Sao_Paulo'})+'T00:00:00');
  let month = new Date(today.getFullYear(), today.getMonth(), 1);
  const lastDate = new Date(today);
  const dateKey = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const availableDates = [];
  while(availableDates.length < config.availableBusinessDays){
    lastDate.setDate(lastDate.getDate()+1);
    if(![0,6].includes(lastDate.getDay()))availableDates.push(dateKey(lastDate));
  }
  const isAvailableDate = value => availableDates.includes(value);
  const parseDate = value => new Date(`${value}T12:00:00`);
  const friendlyDate = value => parseDate(value).toLocaleDateString('pt-BR', { day:'2-digit', month:'long', year:'numeric' });
  const unit = () => config.units.find(u => u.id === state.unit);
  function options(select, values, placeholder) {
    select.replaceChildren(new Option(placeholder, ''));
    values.forEach(v => select.add(new Option(v.name || v, v.id || v)));
  }
  options($('unit'), config.units, 'Selecione uma unidade');
  function clearError() {
    $('form-error').hidden = true; $('phone-error').hidden = true;
    $('phone').removeAttribute('aria-invalid');
  }
  function closeCalendar(returnFocus = false) {
    $('calendar').hidden = true; $('date-trigger').setAttribute('aria-expanded','false');
    if (returnFocus) $('date-trigger').focus();
  }
  function refresh() {
    $('unit').disabled = !state.category;
    $('unit').value = state.unit;
    $('unit-help').textContent = state.unit ? unit().detail : state.category ? 'Escolha a unidade em que deseja ser atendido.' : 'Selecione primeiro a categoria do serviço.';
    $('date-trigger').disabled = !state.unit;
    $('date-label').textContent = state.date ? parseDate(state.date).toLocaleDateString('pt-BR') : 'Selecione uma data';
    $('date-help').textContent = state.unit ? 'Três datas de demonstração disponíveis no calendário.' : 'Escolha uma unidade para consultar as datas.';
    $('time').disabled = !state.date;
    options($('time'), state.date ? unit().times : [], 'Selecione um horário');
    $('time').value = state.time;
    $('time-help').textContent = state.date ? 'Horários simulados para a data escolhida.' : 'Escolha uma data para ver os horários.';
    $('contact-section').hidden = !state.time;
    clearError();
  }
  $('category').addEventListener('change', e => {
    state.category = e.target.value; state.unit = state.date = state.time = ''; closeCalendar(); refresh();
  });
  $('unit').addEventListener('change', e => {
    state.unit = e.target.value; state.date = state.time = ''; closeCalendar(); refresh();
  });
  $('time').addEventListener('change', e => {state.time = e.target.value; refresh();});
  // Do not truncate international paste or move the caret on every keystroke.
  function contactDigits(value) {
    let digits=value.replace(/\D/g,'');
    if(digits.length===15&&digits.startsWith('0055'))digits=digits.slice(4);
    else if(digits.length===13&&digits.startsWith('55'))digits=digits.slice(2);
    return digits;
  }
  function syncContact() {
    const digits=contactDigits($('phone').value);
    state.phone=digits.length===11?`(${digits.slice(0,2)}) ${digits.slice(2,7)}-${digits.slice(7)}`:$('phone').value.trim();
    $('phone').value=state.phone;
    return digits;
  }
  $('phone').addEventListener('input', e => {state.phone=e.target.value;clearError();});
  $('phone').addEventListener('blur',syncContact);
  function renderCalendar() {
    $('calendar-month').textContent = month.toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
    $('previous-month').disabled = month <= new Date(today.getFullYear(),today.getMonth(),1);
    $('next-month').disabled = month >= new Date(lastDate.getFullYear(),lastDate.getMonth(),1);
    const grid = $('calendar-days'); grid.replaceChildren();
    for (let i=0; i<month.getDay(); i++) {const span=document.createElement('span'); grid.append(span);}
    const count = new Date(month.getFullYear(), month.getMonth()+1, 0).getDate();
    for (let day=1;day<=count;day++) {
      const date = new Date(month.getFullYear(),month.getMonth(),day);
      const key=dateKey(date), button=document.createElement('button');
      button.type='button'; button.textContent=day; button.dataset.date=key;
      button.setAttribute('aria-label',friendlyDate(key));
      button.disabled = !isAvailableDate(key);
      button.classList.toggle('selected',state.date===key); button.setAttribute('aria-pressed',String(state.date===key));
      button.addEventListener('click',()=>{state.date=key;state.time='';closeCalendar(true);refresh();});
      grid.append(button);
    }
  }
  $('date-trigger').addEventListener('click',()=>{
    if (!$('calendar').hidden) return closeCalendar();
    if (state.date) {const d=parseDate(state.date);month=new Date(d.getFullYear(),d.getMonth(),1);}
    renderCalendar(); $('calendar').hidden=false; $('date-trigger').setAttribute('aria-expanded','true');
    ($('calendar-days').querySelector('.selected') || $('calendar-days').querySelector('button:not(:disabled)') || $('next-month')).focus();
  });
  $('previous-month').addEventListener('click',()=>{month.setMonth(month.getMonth()-1);renderCalendar();});
  $('next-month').addEventListener('click',()=>{month.setMonth(month.getMonth()+1);renderCalendar();});
  $('calendar').addEventListener('keydown',e=>{
    if(e.key==='Escape'){e.preventDefault();closeCalendar(true);}
    const offsets={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7};
    if(e.target.dataset.date && e.key in offsets){
      e.preventDefault(); const d=parseDate(e.target.dataset.date);d.setDate(d.getDate()+offsets[e.key]);
      const next=$('calendar-days').querySelector(`[data-date="${dateKey(d)}"]`);
      if(next && !next.disabled) next.focus();
    }
  });
  document.addEventListener('click',e=>{if(!e.target.closest('.date-control'))closeCalendar();});
  document.addEventListener('focusin',e=>{if(!e.target.closest('.date-control'))closeCalendar();});
  function valid() {
    const problems = [[!state.category,'Selecione a categoria do serviço.','category'],[!unit(),'Selecione uma unidade de atendimento.','unit'],[!state.date,'Selecione uma data disponível.','date-trigger'],[!state.time || !unit()?.times.includes(state.time),'Selecione um horário disponível.','time']];
    for(const [invalid,message,field] of problems) if(invalid){$('form-error').textContent=message;$('form-error').hidden=false;$(field).focus();return false;}
    const digits=syncContact();
    if(!/^[1-9][0-9]9[0-9]{8}$/.test(digits)){
      $('phone-error').textContent='Informe um celular com DDD e 11 dígitos. Ex.: (61) 99999-9999.';
      $('phone-error').hidden=false;$('phone').setAttribute('aria-invalid','true');
      $('form-error').textContent='Confira o número de contato para continuar.';$('form-error').hidden=false;
      $('phone').focus();return false;
    }
    return true;
  }
  function summary(target, data = state) {
    const selectedUnit = config.units.find(u=>u.id===data.unit);
    target.replaceChildren();
    [['Categoria',data.category],['Unidade',selectedUnit.name,selectedUnit.detail],['Data',friendlyDate(data.date)],['Horário',`${data.time} (horário de Brasília)`],['WhatsApp',`+55 ${data.phone}`]].forEach(([label,value,detail])=>{
      const row=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');
      dt.textContent=label;dd.textContent=value;
      if(detail){const small=document.createElement('small');small.textContent=detail;dd.append(small);}
      row.append(dt,dd);target.append(row);
    });
  }
  function showStep(step) {
    state.step=step;
    ['booking-panel','review-panel','success-panel'].forEach((id,i)=>$(id).hidden=i!==step);
    document.querySelectorAll('.stepper li').forEach((li,i)=>{
      li.classList.toggle('active',i===step);li.classList.toggle('complete',i<step);
      if(i===step)li.setAttribute('aria-current','step');else li.removeAttribute('aria-current');
      li.querySelector('span').textContent=i<step?'✓':i+1;
    });
    const titles=['booking-title','review-title','success-title'];
    $(titles[step]).focus({preventScroll:true});
    const panel=$(['booking-panel','review-panel','success-panel'][step]);
    if(!panel.closest('[hidden]'))panel.scrollIntoView({behavior:'auto',block:'start'});
  }
  $('booking').addEventListener('submit',e=>{e.preventDefault();if(valid()){closeCalendar();summary($('review-data'));showStep(1);}});
  $('edit-button').addEventListener('click',()=>showStep(0));
  $('confirm-button').addEventListener('click',()=>{
    if(state.step!==1 || !valid())return;
    state.protocol=`DEMO-${String(Date.now()).slice(-6)}`;
    appointment={...state,status:'agendado'}; waStarted=false; $('wa-messages').replaceChildren();
    $('protocol').textContent=state.protocol;summary($('success-data'));showStep(2);
  });
  function resetDraft() {
    Object.assign(state,{category:'',unit:'',date:'',time:'',phone:'',protocol:'',step:0});
    $('booking').reset();refresh();closeCalendar();month=new Date(today.getFullYear(),today.getMonth(),1);showStep(0);
  }
  $('restart-button').addEventListener('click',()=>{
    appointment=null;waStarted=false;$('wa-messages').replaceChildren();resetDraft();navigate('inicio');
  });
  $('new-booking').addEventListener('click',()=>resetDraft());
  $('calendar-download').addEventListener('click',()=>{
    const start=new Date(`${state.date}T${state.time}:00-03:00`),end=new Date(start.getTime()+30*60000);
    const stamp=d=>d.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
    const text=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//IHC//Biometria DEMO//PT-BR','BEGIN:VEVENT',`UID:${state.protocol}@prototipo.invalid`,`DTSTAMP:${stamp(new Date())}`,`DTSTART:${stamp(start)}`,`DTEND:${stamp(end)}`,'SUMMARY:[SIMULADO] Coleta de biometria',`LOCATION:${unit().name}`,'DESCRIPTION:Protótipo acadêmico. Nenhum atendimento real foi reservado.','END:VEVENT','END:VCALENDAR',''].join('\r\n');
    const url=URL.createObjectURL(new Blob([text],{type:'text/calendar;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='agendamento-simulado.ics';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  // One appointment record is shared between the portal and the simulated chat.
  function renderConsult() {
    $('empty-bookings').hidden=!!appointment;$('current-booking').hidden=!appointment;
    if(!appointment)return;
    summary($('consult-data'),appointment);
    const labels={agendado:'Agendado',confirmado:'Presença confirmada',reagendado:'Reagendado',cancelado:'Cancelado'};
    $('appointment-status').textContent=labels[appointment.status];
    $('appointment-status').classList.toggle('cancelled',appointment.status==='cancelado');
    $('consult-protocol').textContent=`Protocolo de demonstração: ${appointment.protocol}`;
    $('consult-whatsapp').textContent=appointment.status==='cancelado'?'Ver conversa no WhatsApp →':'Gerenciar pelo WhatsApp →';
  }
  const views={inicio:'home-view',agendamentos:'services-view',presencial:'attendance-view',agendar:'booking-view',consulta:'consult-view',whatsapp:'whatsapp-view'};
  function navigate(route) { if(location.hash!==`#${route}`)location.hash=route;else renderRoute(); }
  function renderRoute() {
    let route=decodeURIComponent(location.hash.slice(1))||'inicio';
    if(!(route in views))route='inicio';
    if(route==='whatsapp'&&!appointment){location.replace('#consulta');return;}
    document.querySelectorAll('.portal-view').forEach(v=>v.hidden=v.id!==views[route]);
    const isChat=route==='whatsapp';
    $('whatsapp-view').hidden=!isChat;
    document.querySelector('.header').hidden=isChat;
    $('main').hidden=isChat;document.querySelector('body > footer').hidden=isChat;
    document.body.classList.toggle('in-whatsapp',isChat);
    if(route==='consulta')renderConsult();
    if(isChat){initWhatsApp();$('wa-input').focus({preventScroll:true});scrollChat();}
    else { const title=$(views[route]).querySelector('h1,h2'); if(title)title.focus({preventScroll:true});window.scrollTo(0,0); }
    document.title=isChat?'Detran-DF · WhatsApp simulado':'Agendamento de biometria · Detran-DF';
  }
  function scrollChat(){ $('wa-messages').scrollTop=$('wa-messages').scrollHeight; }
  function bubble(text, sender='bot') {
    const article=document.createElement('article');article.className=`wa-bubble ${sender}`;
    const content=document.createElement('p');content.textContent=text;article.append(content);
    const time=document.createElement('small');time.className='wa-time';time.textContent=new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',timeZone:'America/Sao_Paulo'})+(sender==='user'?'  ✓✓':'');article.append(time);
    $('wa-messages').append(article);$('wa-chat-preview').textContent=text.split('\n')[0];scrollChat();return article;
  }
  function disablePreviousControls(){
    $('wa-messages').querySelectorAll('button,input,select').forEach(el=>{
      if(el.tagName==='INPUT'&&el.type==='date'&&el.value){const value=parseDate(el.value).toLocaleDateString('pt-BR');el.type='text';el.value=value;}
      el.disabled=true;
    });
    $('wa-messages').querySelectorAll('.wa-reschedule-form').forEach(el=>el.dataset.closed='true');
  }
  function buttons(message, options) {
    const group=document.createElement('div');group.className='wa-options';
    for(const [label,action] of options){const b=document.createElement('button');b.type='button';b.textContent=label;b.dataset.action=action;b.addEventListener('click',()=>chooseAction(action));group.append(b);}
    message.append(group);scrollChat();
  }
  function appointmentText() {return `${friendlyDate(appointment.date)}, às ${appointment.time}\n${config.units.find(u=>u.id===appointment.unit).name}`;}
  function showMenu(text) {
    disablePreviousControls();waMode=appointment.status==='cancelado'?'cancelled':'menu';
    const msg=bubble(text||'Como deseja gerenciar seu atendimento?');
    if(appointment.status!=='cancelado')buttons(msg,[['Confirmar presença','confirm'],['Reagendar','reschedule'],['Cancelar','cancel']]);
    else buttons(msg,[['Voltar ao portal','portal']]);
  }
  function initWhatsApp() {
    if(waStarted)return;waStarted=true;waMode='menu';
    $('wa-messages').replaceChildren();
    const badge=document.createElement('div');badge.className='wa-day';badge.textContent='HOJE · SIMULAÇÃO DE LEMBRETE';$('wa-messages').append(badge);
    const info=document.createElement('div');info.className='wa-disclaimer';info.textContent='Protótipo acadêmico. Nenhuma mensagem é enviada ao WhatsApp real.';$('wa-messages').append(info);
    showMenu(`Olá! Você tem um atendimento de biometria agendado.\n\n${appointmentText()}\n\nEscolha uma das opções abaixo:`);
  }
  function chooseAction(action, fromTyped=false) {
    if(action==='portal'){navigate('consulta');return;}
    if(!appointment||appointment.status==='cancelado')return;
    if(waMode==='reschedule'&&!['back'].includes(action))return;
    if(waMode==='cancel'&&!['cancel-confirm','back'].includes(action))return;
    if(['confirm','reschedule','cancel'].includes(action)&&waMode!=='menu')return;
    if(action==='cancel-confirm'&&waMode!=='cancel')return;
    const names={confirm:'Confirmar presença',reschedule:'Reagendar',cancel:'Cancelar','cancel-confirm':'Sim, cancelar',back:'Voltar'};
    disablePreviousControls();if(!fromTyped)bubble(names[action]||action,'user');
    if(action==='confirm'){
      appointment.status='confirmado';waMode='menu';
      const msg=bubble(`Presença confirmada! ✓\n\nTe esperamos em ${appointmentText()}.\n\nLeve seu documento de identificação e chegue com 15 minutos de antecedência.`);
      buttons(msg,[['Gerenciar atendimento','menu'],['Consultar no portal','portal']]);
    } else if(action==='reschedule') {waMode='reschedule';renderReschedule();}
    else if(action==='cancel') {
      waMode='cancel';const msg=bubble(`Deseja cancelar seu atendimento?\n\n${appointmentText()}\n\nSua vaga será liberada somente após a confirmação.`);
      buttons(msg,[['Sim, cancelar','cancel-confirm'],['Voltar','back']]);
    } else if(action==='cancel-confirm') {
      appointment.status='cancelado';waMode='cancelled';
      const msg=bubble('Agendamento cancelado com sucesso.\nA vaga foi liberada.');buttons(msg,[['Consultar no portal','portal']]);
    } else if(action==='back')showMenu('Seu agendamento foi mantido. Como deseja continuar?');
    else if(action==='menu')showMenu();
    scrollChat();
  }
  function renderReschedule() {
    const msg=bubble('Reagendar biometria\nEscolha uma nova data e um novo horário. O atendimento atual será mantido até você confirmar a alteração.');
    const form=document.createElement('form');form.className='wa-reschedule-form';
    const n=++messageCounter;
    const dateLabel=document.createElement('label');dateLabel.htmlFor=`wa-date-${n}`;dateLabel.textContent='Nova data';
    const date=document.createElement('input');date.type='date';date.id=dateLabel.htmlFor;date.name='new-date';date.lang='pt-BR';date.required=true;date.min=dateKey(new Date(today.getFullYear(),today.getMonth(),today.getDate()+1));date.max=dateKey(lastDate);
    const dateHint=document.createElement('small');dateHint.className='wa-date-summary';dateHint.id=`wa-date-help-${n}`;dateHint.textContent='Selecione um dia no calendário.';date.setAttribute('aria-describedby',dateHint.id);
    const timeLabel=document.createElement('label');timeLabel.htmlFor=`wa-time-${n}`;timeLabel.textContent='Novo horário';
    const time=document.createElement('select');time.id=timeLabel.htmlFor;time.name='new-time';time.required=true;time.disabled=true;options(time,[],'Selecione um horário');
    const error=document.createElement('p');error.className='wa-form-error';error.setAttribute('role','alert');
    const submit=document.createElement('button');submit.type='submit';submit.className='wa-confirm-reschedule';submit.textContent='Confirmar reagendamento';
    date.addEventListener('change',()=>{
      const d=parseDate(date.value),ok=isAvailableDate(date.value);
      options(time,ok?config.units.find(u=>u.id===appointment.unit).times.filter(t=>date.value!==appointment.date||t!==appointment.time):[],'Selecione um horário');time.disabled=!ok;
      dateHint.textContent=ok?`Data escolhida: ${friendlyDate(date.value)}`:'Selecione um dia útil disponível.';
      error.textContent=ok?'':'Escolha uma das três datas disponíveis no calendário.';date.setCustomValidity(ok?'':'Selecione uma data disponível.');
    });
    form.addEventListener('submit',e=>{
      e.preventDefault();if(waMode!=='reschedule'||form.dataset.closed)return;
      const d=parseDate(date.value),validDate=isAvailableDate(date.value);
      const validTime=config.units.find(u=>u.id===appointment.unit).times.includes(time.value);
      if(!validDate||!validTime){error.textContent='Escolha uma data e um horário disponíveis.';return;}
      if(date.value===appointment.date&&time.value===appointment.time){error.textContent='Escolha uma data ou horário diferente do agendamento atual.';return;}
      const newDate=date.value,newTime=time.value;
      disablePreviousControls();bubble(`Nova data: ${friendlyDate(newDate)}, às ${newTime}`,'user');
      appointment.date=newDate;appointment.time=newTime;appointment.status='reagendado';
      // Synchronize the completed portal record as well as consultation and chat.
      state.date=newDate;state.time=newTime;refresh();summary($('success-data'),appointment);
      waMode='menu';const reply=bubble(`Reagendamento concluído! ✓\n\n${appointmentText()}\n\nA vaga anterior foi liberada.`);buttons(reply,[['Gerenciar atendimento','menu'],['Consultar no portal','portal']]);scrollChat();
    });
    form.append(dateLabel,date,dateHint,timeLabel,time,error,submit);msg.append(form);buttons(msg,[['Voltar sem alterar','back']]);scrollChat();date.focus({preventScroll:true});
  }
  $('wa-composer').addEventListener('submit',e=>{
    e.preventDefault();const text=$('wa-input').value.trim();if(!text)return;$('wa-input').value='';bubble(text,'user');
    const normalized=text.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[.!?]/g,'').trim();
    if(waMode==='cancelled'){bubble('Este agendamento foi cancelado. Volte ao portal para iniciar um novo atendimento.');return;}
    const mapping={'confirmar presenca':'confirm','confirmar':'confirm','reagendar':'reschedule','cancelar':'cancel','sim cancelar':'cancel-confirm','sim, cancelar':'cancel-confirm','voltar':'back','menu':'menu'};
    const action=mapping[normalized];
    if(waMode==='reschedule'&&action!=='back'){bubble('Use o formulário acima para escolher uma nova data e horário, ou selecione Voltar sem alterar.');return;}
    if(waMode==='cancel'&&!['cancel-confirm','back'].includes(action)){bubble('Escolha Sim, cancelar para confirmar, ou Voltar para manter seu agendamento.');return;}
    if(action){chooseAction(action,true);return;}
    bubble('Neste protótipo, você pode confirmar presença, reagendar ou cancelar. Use os botões da conversa ou digite uma dessas opções.');
  });
  $('whatsapp-button').addEventListener('click',()=>navigate('whatsapp'));
  $('consult-whatsapp').addEventListener('click',()=>navigate('whatsapp'));
  $('wa-return-portal').addEventListener('click',()=>navigate('consulta'));
  $('wa-selected-chat').addEventListener('click',()=>{$('wa-input').focus();scrollChat();});
  document.querySelector('.brand').addEventListener('click',e=>{e.preventDefault();navigate('inicio');});
  window.addEventListener('hashchange',renderRoute);
  refresh();renderRoute();
})();
