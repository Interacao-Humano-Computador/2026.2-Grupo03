// Opções simuladas para a avaliação acadêmica.
window.PROTOTYPE_CONFIG = {
  availableBusinessDays: 3,
  units: [
    { id: 'asa-norte', name: 'Unidade Asa Norte', detail: 'Asa Norte • Brasília, DF', times: ['08:00', '09:00', '15:00'] },
    { id: 'taguatinga', name: 'Unidade Taguatinga', detail: 'Taguatinga • Distrito Federal', times: ['09:30', '14:30', '15:30'] },
    { id: 'gama', name: 'Unidade Gama', detail: 'Gama • Distrito Federal', times: ['08:00', '11:00', '13:00'] }
  ]
};
